import img11 from "../../../Assets/slider/slider (11).jpg";
import img12 from "../../../Assets/slider/slider (12).jpg";
import img13 from "../../../Assets/slider/slider (13).jpg";
import img14 from "../../../Assets/slider/slider (14).jpg";
import img15 from "../../../Assets/slider/slider (15).jpg";
import img16 from "../../../Assets/slider/slider (16).jpg";
import img17 from "../../../Assets/slider/slider (17).jpg";

export const sliderDataB = [
    {
        id: 11,
        img: img11,
    },
    {
        id: 12,
        img: img12,
    },
    {
        id: 13,
        img: img13,
    },
    {
        id: 14,
        img: img14,
    },
    {
        id: 15,
        img: img15,
    },
    {
        id: 16,
        img: img16,
    },
    {
        id: 17,
        img: img17,
    },
];