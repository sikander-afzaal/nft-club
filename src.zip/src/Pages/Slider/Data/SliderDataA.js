import img1 from "../../../Assets/slider/slider (1).jpg";
import img2 from "../../../Assets/slider/slider (2).jpg";
import img3 from "../../../Assets/slider/slider (3).jpg";
import img4 from "../../../Assets/slider/slider (4).jpg";
import img5 from "../../../Assets/slider/slider (5).jpg";
import img6 from "../../../Assets/slider/slider (6).jpg";
import img7 from "../../../Assets/slider/slider (7).jpg";
import img8 from "../../../Assets/slider/slider (8).jpg";
import img9 from "../../../Assets/slider/slider (9).jpg";
import img10 from "../../../Assets/slider/slider (10).jpg";

export const sliderDataA = [
    {
        id: 1,
        img: img1,
        price: 0.5
    },
    {
        id: 2,
        img: img2,
        price: 0.1
    },
    {
        id: 3,
        img: img3,
        price: 0.7
    },
    {
        id: 4,
        img: img4,
        price: 0.9
    },
    {
        id: 5,
        img: img5,
        price: 2.5
    },
    {
        id: 6,
        img: img6,
        price: 1.5
    },
    {
        id: 7,
        img: img7,
        price: 5.5
    },
    {
        id: 8,
        img: img8,
        price: 9.5
    },
    {
        id: 9,
        img: img9,
        price: 0.5
    },
    {
        id: 10,
        img: img10,
        price: 0.5
    },
];