import React from "react";
import LogoImg from "../../Assets/Logo-img.svg";

function Logo() {
  return (
    <div>
      <img src={LogoImg} style={{ width: "100%" }} alt="..." />
    </div>
  );
}

export default Logo;
